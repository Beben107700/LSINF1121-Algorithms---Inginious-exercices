import be.ac.ucl.info.javagrading.Grade;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;


public class BSTTestExtreme {


    @Test
    @Grade(value=15)
    public void testIteratorList() {
        char db[] = new char[] {'S', 'E', 'A', 'R', 'C', 'H', 'E', 'X', 'A', 'M', 'P', 'L', 'E'};
        BST<String, Integer> student = new BST<String, Integer>();

        Iterator<String> iterator = student.iterator();
        //assertFalse(iterator.hasNext());

        Set<String> correct = new TreeSet<>();
        for (int i = 0; i < db.length; i++) {
            String key = ""+db[i];
            student.put(key, i);
            if (i==6) {
                assertEquals(i,student.size());
            }
            assertEquals(student.get(key).intValue(),i);
            correct.add(key);
        }

        Iterator<String> aIter = student.iterator();
        Iterator<String> bIter = correct.iterator();

        while (bIter.hasNext()) {
            assertTrue(aIter.hasNext());
            assertEquals(bIter.next(),aIter.next());
        }
        assertFalse(bIter.hasNext());
        assertFalse(aIter.hasNext());

    }

    @Test(expected = NoSuchElementException.class)
    @Grade(value=10)
    public void testNoSuchElementException() {
        BST<String,Integer> student = new BST<>();
        student.iterator().next();

    }


    @Test(expected = ConcurrentModificationException.class)
    @Grade(value=10)
    public void testConcurrentModificationNext() {
        BST<String,Integer> student = new BST<>();
        student.put("A",1);

        Iterator iter = student.iterator();
        student.put("B",2);
        iter.next();
    }



    @Test
    public void mine(){
        BST< Integer, Character > bst = new BST<>();
        bst.put(4, 'd');
        bst.put(2, 'b');
        bst.put(6, 'f');
        bst.put(1, 'a');
        bst.put(3, 'c');
        bst.put(5, 'e');
        bst.put(7, 'f');
        Iterator<Integer> it = bst.iterator();
        it.hasNext();
        for (int i=0; i<7; i++ ){
            it.hasNext();
            it.next();
        }
    }

}

